# da3456 — 基于「映间 MARGIN」的本地改版

## 来源与许可

本扩展是 [jiuyang5354/bilibili-margin](https://github.com/jiuyang5354/bilibili-margin) **v0.49.1** 的修改版（fork）。
上游采用 **MIT License**，完整文本见同目录的 `LICENSE` 文件，版权声明人为上游作者 `jiuyang5354`。
按 MIT 条款，本包保留该版权声明与许可文本；本目录内代码的版权归属仍按 `LICENSE` 执行。

本 fork 与 B 站（bilibili.com）无任何关系，未获其认可或背书；页面数据全部来自 B 站自己的公开接口。

## 本改版相对上游 v0.49.1 的改动

1. **三页顶栏完全一致**（首页 / 播放页 / 搜索页，含直播、空间等换皮页）
   - 新增顶栏专用左右留白变量 `--hg`，与首页栅格的 `--g` 解耦，并在 1700 / 1279 / 900px 三档断点上统一。此前同视口下首页两侧 56px、播放与搜索页 240px，logo、搜索框、头像的横向位置对不齐。
   - 首页搜索胶囊常显，去掉滚动时收起的 `no-search` / `hs-away` 机制。
   - 顶栏入口统一为同一份列表（`headTabs()`）：B 站原生入口 + 分隔线 + 收藏 / 稍后 / 足迹 / 设置 / 原版。
2. **搜索页整条顶栏偏左修复**
   - `content.js`：`html.margin-watch { scrollbar-width: thin }` → `html.margin-skin { scrollbar-width: thin }`。原生滚动条约 15.2px、细滚动条约 10px，`position: fixed` 的顶栏宽度按「视口 − 滚动条」计算；原先只有播放页设了细滚动条，所以搜索页、空间页整体左偏约 2.4px。
3. **视频详情页看不到弹幕修复**
   - `content.js`：两处「减少动画」规则（用户开关 `.margin-reduce` 与 `@media (prefers-reduced-motion: reduce)`）改为放行播放器子树：`:not(.bpx-player-container, .bpx-player-container *)`（含 `::before` / `::after`）。B 站弹幕是 DOM + CSS 动画（`.bili-danmaku-x-roll` 使用 `animation: roll 8s 1 forwards`），动画时长被压成 0.001ms 后弹幕一挂载就瞬间飞到轨道终点，屏幕上永远不出现。
4. **发布为本 fork 所做的整理**
   - 名称改为 `da3456`（商店显示名、弹窗标题、页面标题与页脚、返回按钮、导入导出提示等用户可见文案）。
   - 移除「向上游 GitHub Releases 查询新版本」的逻辑，扩展不再向 `api.github.com` 发请求。
   - 发布包不含 `.bak*` 回滚副本与商店宣传素材。

## 实现说明（重要）

上述第 1–3 条的改动是**手工打在构建产物上的**（本目录即产物），不是由源码重新编译得到：本机 shell 里是 Node v16.16.0 且没有 `node_modules`，而项目 `package.json` 要求 Node ≥ 20.19 与 vite ^8。

对应源码（含同样的改动）另存于同级的 `bilibili-margin-mod-src`。如果以后要重新构建，请以该目录为准，需要 Node ≥ 20.19 + `npm install` + `npm run build`；构建产物里字体子集来自 `fonts-src/`，不要直接覆盖本目录。
